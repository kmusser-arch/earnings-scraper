#!/usr/bin/env python3

import sys
import time
import signal
import enum
import socket
import ujson
import journal
import journal.utils
from . import auth
from .sources import NO_BODY_SOURCES
from .platforms import PLATFORMS


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class ConnectionRateLimitError(Exception):
    """Raised when connection attempts exceed the configured rate limit."""
    pass


# ---------------------------------------------------------------------------
# Connection state
# ---------------------------------------------------------------------------

class ConnectionState(enum.Enum):
    """
    Observable connection state for a NewsGatewayClient.

    CONNECTED: no disconnect has been detected yet. Does not by itself mean
    data is actively flowing -- a quiet source looks identical to a healthy
    one from this state alone. Use ``seconds_since_last_activity`` if you
    need to distinguish "quiet" from "definitely still connected."

    DISCONNECTED: the underlying socket was found closed or errored, either
    from a clean close (EOFError) or a hard reset (OSError and subclasses
    such as ConnectionResetError). One-way -- a client that reaches this
    state stays here; reconnecting means constructing a new client.
    """
    CONNECTED = 'connected'
    DISCONNECTED = 'disconnected'


# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------

class ConnectionRateLimiter:
    """
    Sliding-window rate limiter for connection attempts.

    Tracks timestamps of recent attempts; raises ConnectionRateLimitError
    if max_attempts is exceeded within window_seconds.

    Default: 5 attempts per 60 seconds.
    """

    def __init__(self, max_attempts=5, window_seconds=60):
        self._max = max_attempts
        self._window = window_seconds
        self._times = []

    def check_and_record(self):
        now = time.monotonic()
        cutoff = now - self._window
        self._times = [t for t in self._times if t > cutoff]
        if len(self._times) >= self._max:
            retry_in = self._times[0] + self._window - now
            raise ConnectionRateLimitError(
                f"Too many connection attempts "
                f"({self._max} per {self._window}s). "
                f"Retry in {retry_in:.0f}s."
            )
        self._times.append(now)


# ---------------------------------------------------------------------------
# NDJSON frame parser
# ---------------------------------------------------------------------------

class _ByteFIFO:
    def __init__(self):
        self._buf = bytearray()

    def write(self, data):
        self._buf.extend(data)

    def read(self, size):
        data = self._buf[:size]
        del self._buf[:size]
        return data

    def readline(self):
        idx = self._buf.find(b'\n')
        if idx == -1:
            return None
        return self.read(idx + 1)


class _NdjsonHandler:
    """Parses NDJSON frames and dispatches each object to a callback."""

    def __init__(self, callback, post_process=None):
        self._pipe = _ByteFIFO()
        self._cb = callback
        self._post_process = post_process

    def handle(self, data):
        self._pipe.write(data)
        line = self._pipe.readline()
        while line:
            obj = ujson.loads(line)
            if not isinstance(obj, dict):
                raise ValueError('Expected a JSON object')
            if self._post_process:
                self._post_process(obj)
            self._cb(obj)
            line = self._pipe.readline()


def _news_post_process(obj):
    if obj.get('source') in NO_BODY_SOURCES:
        obj.pop('body', None)


# ---------------------------------------------------------------------------
# Subscription tracking (for reconnect() replay)
# ---------------------------------------------------------------------------

class _TrackedFuture:
    """
    Wraps a SessionFuture so cancel() also drops the subscription from the
    client's replay-on-reconnect list -- a cancelled subscription should not
    come back from under the caller the next time reconnect() runs.
    """
    def __init__(self, client, key, future):
        self._client = client
        self._key = key
        self._future = future

    def cancel(self):
        self._client._active_subscriptions.pop(self._key, None)
        return self._future.cancel()

    def __getattr__(self, name):
        return getattr(self._future, name)


# ---------------------------------------------------------------------------
# Main client
# ---------------------------------------------------------------------------

class NewsGatewayClient(journal.Session):
    """
    Client for the SHEL data gateway API (news, scribe, social).

    Connects to the SHELDataEngine, logs in, and provides subscribe methods
    for each available feed type. All feeds share a single connection.

    Parameters
    ----------
    environment : Environment
        One of environments.Staging, environments.Prod, or a custom Environment.
    user_id : str
        The SHEL user ID used for login and entitlement lookup.
    token : str, optional
        JWT token issued by https://shel.trilliumtrading.com. When provided, the
        server verifies the signature and derives the authoritative username from
        the token payload, preventing impersonation. Recommended for all non-internal
        clients. See auth.get_token() for a helper that caches a fetched token
        across runs so you aren't prompted for a password more than once a day;
        the CLI entry point already uses it.
    rate_limiter : ConnectionRateLimiter, optional
        Overrides the default rate limiter (5 attempts / 60s). Also applied
        to reconnect() attempts, so a reconnect loop can't hammer the server.
    on_disconnect : callable, optional
        Called with the triggering exception (EOFError or OSError/subclass)
        the moment a disconnect is detected inside wait()/try_wait(). Purely
        additive -- the original exception is still re-raised afterward, so
        existing error handling around wait() is unaffected whether or not
        this is provided.
    on_reconnect : callable, optional
        Called with no arguments immediately after reconnect() succeeds
        (new socket, re-login, every tracked subscription replayed), so a
        reconnect isn't silently invisible to the caller either.
    token_provider : callable, optional
        Called with no arguments to obtain a token for every login attempt,
        including reconnects -- e.g. ``token_provider=lambda: auth.get_token(user_id)``.
        Use this instead of a static ``token`` if you want reconnect()/
        wait_and_reconnect()/auto_reconnect to work with a token that can
        expire; a plain ``token`` string is reused as-is for every re-login
        and will simply fail once it's stale. Takes priority over ``token``
        when both are given.
    auto_reconnect : bool, optional
        Default True. When a disconnect is detected inside wait()/try_wait(),
        automatically call wait_and_reconnect(timeout=auto_reconnect_timeout)
        before giving up. on_disconnect (and on_reconnect, if the auto-heal
        succeeds) still fire every time regardless of this setting -- this
        only controls whether the client also tries to recover on its own,
        never whether the event is visible. Set False for full manual
        control instead (call reconnect()/wait_and_reconnect() yourself).
        Note: with this on, try_wait() can block for up to
        auto_reconnect_timeout seconds while retrying, which is otherwise
        not part of its contract.
    auto_reconnect_timeout : float, optional
        Default 21600 (6 hours). Two things: (1) how long a single
        reconnect burst keeps retrying before giving up, and (2) the
        cooldown before another burst is attempted after one fails. So
        with the default, at most one bounded retry burst runs roughly
        every 6 hours for as long as the caller keeps calling
        wait()/try_wait() -- not a tight loop hammering the server, and
        not silent per-attempt noise either: see the Notes section for
        exactly what fires and when. Sized to comfortably cover the news
        gateway's nightly maintenance window (~10pm-3am, so up to ~5 hours
        down) with margin either side, so a process left running
        overnight recovers on its own the next morning without needing a
        human -- as long as token_provider can still produce a valid
        token when the server comes back (see TokenPromptUnavailable:
        that part always requires a human, by design, if the cached token
        has expired by then). Call wait_and_reconnect(timeout=None)
        yourself instead of relying on this if you want a single call that
        blocks until it recovers with no bound at all.

    Attributes
    ----------
    connection_state : ConnectionState
        CONNECTED until a disconnect is detected, then DISCONNECTED until a
        successful reconnect() (or for the lifetime of the client if none
        is attempted, or if attempted and it failed).
    disconnect_reason : Exception or None
        The exception that triggered the DISCONNECTED transition, or None
        if still connected.
    seconds_since_last_activity : float
        Time since the last frame of any kind was received (including
        frames for other subscriptions/sources on the same connection).
        Measured from connect time if no frame has arrived yet. Useful for
        a caller-side "is this actually stuck or just quiet" heuristic --
        the SDK does not run any background watchdog itself.

    Notes
    -----
    Every disconnect is always surfaced via connection_state/on_disconnect
    at the moment it starts, whether or not auto_reconnect is on -- that
    part is never silent. What auto_reconnect controls is only whether the
    client also tries to recover the connection itself afterward, versus
    leaving that entirely to the caller.

    With auto_reconnect on, a single continuous outage produces exactly one
    on_disconnect call, not one per failed attempt: if wait()/try_wait() is
    called again while a reconnect burst's cooldown hasn't elapsed yet, it
    just re-raises the same disconnect immediately without re-attempting or
    re-notifying, so a caller's own polling loop can't turn this into a
    hammering/log-spam problem no matter how tightly it's written. Once the
    cooldown elapses, one more bounded burst runs; if that recovers,
    on_reconnect fires and normal operation resumes; if not, the cooldown
    resets and the cycle repeats on the next call. Turn auto_reconnect off
    for strictly manual control instead (e.g. to apply your own policy
    about when reconnecting is appropriate).
    """

    def __init__(self, environment, user_id, token=None, rate_limiter=None,
                 on_disconnect=None, on_reconnect=None, token_provider=None,
                 auto_reconnect=True, auto_reconnect_timeout=21600):
        self._user_id = user_id
        self._token = token
        self._token_provider = token_provider
        self._rate_limiter = rate_limiter or ConnectionRateLimiter()
        self._rate_limiter.check_and_record()
        self._on_disconnect = on_disconnect
        self._on_reconnect = on_reconnect
        self._auto_reconnect = auto_reconnect
        self._auto_reconnect_timeout = auto_reconnect_timeout
        self._next_reconnect_attempt_time = 0.0
        self._active_subscriptions = {}
        self._next_subscription_key = 0
        self.connection_state = ConnectionState.CONNECTED
        self.disconnect_reason = None
        super().__init__(
            environment.SHEL_DATA_ENGINE_HOST,
            environment.SHEL_DATA_ENGINE_PORT,
            journal.utils.any_decompress,
        )
        self._last_frame_time = time.monotonic()
        self._login()

    # TCP has no built-in way to notice a dead peer -- a connection only
    # tears down when the other side actually sends something (a clean
    # close or a reset). A severed link (a pulled cable, a black-holed
    # route) sends neither, so without keepalive, wait()'s blocking recv()
    # just hangs forever with connection_state stuck at CONNECTED. Confirmed
    # by reproduction: a server that subscribes then goes silent without
    # closing hangs wait() indefinitely, no error, ever. labs-journal's
    # TCPClient never enables SO_KEEPALIVE, so this is fixed locally here
    # rather than in that shared package -- see the separate write-up for a
    # proper fix there. Worst-case detection time is roughly
    # _KEEPALIVE_IDLE + _KEEPALIVE_INTERVAL * _KEEPALIVE_COUNT (~15s) --
    # comfortably clears typical self-healing blips (a WiFi roam, a VPN
    # rekey) while still giving prompt, honest visibility into a real dead
    # link. 5 probes (not fewer) so one dropped packet isn't mistaken for
    # a dead connection.
    _KEEPALIVE_IDLE = 5
    _KEEPALIVE_INTERVAL = 2
    _KEEPALIVE_COUNT = 5

    def connect(self, host=None, port=None):
        super().connect(host, port)
        self._enable_keepalive()

    def _enable_keepalive(self):
        raw = self.sock.sock
        raw.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        idle, interval, count = self._KEEPALIVE_IDLE, self._KEEPALIVE_INTERVAL, self._KEEPALIVE_COUNT
        if sys.platform == 'win32':
            raw.ioctl(socket.SIO_KEEPALIVE_VALS, (1, idle * 1000, interval * 1000))
        elif sys.platform == 'darwin':
            # macOS only exposes the idle-time knob, under a different name
            tcp_keepalive = getattr(socket, 'TCP_KEEPALIVE', 0x10)
            raw.setsockopt(socket.IPPROTO_TCP, tcp_keepalive, idle)
        else:
            raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, idle)
            raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, interval)
            raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, count)

    def __exit__(self, etype, value, traceback):
        if etype is not None:
            # journal.Session.__exit__ unconditionally calls self.wait()
            # before close(), with no check for whether an exception is
            # already propagating -- fine for a normal clean shutdown
            # (e.g. draining a cancel() ack), but if we're already exiting
            # because of an unrecoverable disconnect, that extra wait()
            # just re-hits the same dead connection, raises a fresh
            # EOFError, fires on_disconnect a second time for the same
            # outage, and then replaces/masks whatever exception was
            # already propagating (e.g. a clean sys.exit(1)) with that new
            # one. Skip the redundant wait() in that case; still close()
            # so the socket doesn't leak, and don't suppress the original
            # exception (return a falsy value).
            self.close()
            return False
        return super().__exit__(etype, value, traceback)

    def _track_subscription(self, method_name, kwargs, future):
        key = self._next_subscription_key
        self._next_subscription_key += 1
        self._active_subscriptions[key] = (method_name, kwargs)
        return _TrackedFuture(self, key, future)

    @property
    def seconds_since_last_activity(self):
        return time.monotonic() - self._last_frame_time

    def _handle_frame(self, *args, **kwargs):
        self._last_frame_time = time.monotonic()
        return super()._handle_frame(*args, **kwargs)

    def _mark_disconnected(self, exc):
        self.connection_state = ConnectionState.DISCONNECTED
        self.disconnect_reason = exc
        if self._on_disconnect:
            self._on_disconnect(exc)

    def _handle_disconnect(self, exc):
        """
        on_disconnect fires once per continuous outage, not once per call,
        regardless of auto_reconnect -- a call that lands while already
        DISCONNECTED just updates disconnect_reason and returns False
        without re-notifying, so a caller's own loop (or the extra wait()
        journal.Session.__exit__ makes during cleanup) can't turn one
        outage into repeated notifications.

        If auto_reconnect is off: always returns False (caller raises
        `exc`) once connection_state is set, every call.

        If auto_reconnect is on: a call that lands while still inside the
        cooldown from the last failed burst returns False immediately
        without attempting a new connection either -- so a caller's own
        loop, however tight, can't turn this into repeated network
        hammering either. Once the cooldown elapses, one more bounded
        burst runs via wait_and_reconnect(timeout=auto_reconnect_timeout);
        True means it recovered (caller should treat this as "nothing new
        this call, try again" rather than raising), False means it failed
        again and the cooldown resets for another cycle.
        ConnectionRateLimitError propagates directly rather than being
        folded into that cooldown, since it's a distinct, actionable
        signal in its own right.
        """
        already_down = self.connection_state == ConnectionState.DISCONNECTED

        if not self._auto_reconnect:
            if not already_down:
                self._mark_disconnected(exc)
            else:
                self.disconnect_reason = exc
            return False

        if already_down and time.monotonic() < self._next_reconnect_attempt_time:
            self.disconnect_reason = exc  # keep current, but don't re-fire on_disconnect
            return False

        if not already_down:
            self._mark_disconnected(exc)  # new episode -- on_disconnect fires
        else:
            self.disconnect_reason = exc  # same episode, cooldown just elapsed

        try:
            self.wait_and_reconnect(timeout=self._auto_reconnect_timeout)
            return True
        except ConnectionRateLimitError:
            raise
        except (EOFError, OSError, journal.RequestError):
            self._next_reconnect_attempt_time = time.monotonic() + self._auto_reconnect_timeout
            return False

    def wait(self, max_count=None):
        try:
            return super().wait(max_count)
        except (EOFError, OSError) as e:
            if self._handle_disconnect(e):
                return None
            raise

    def try_wait(self):
        # journal's own try_wait() can't tell "no data yet" apart from "the
        # connection is at EOF" -- both surface as BlockingIOError from
        # peek_exact_immediate(), since a 0-byte non-blocking peek (real EOF)
        # and a too-short one (genuinely no data yet) both fail its
        # `len(data) < length` check. Probe 1 byte ourselves first: a real
        # BlockingIOError here means no data yet (fall through to normal
        # behavior); an empty successful read means EOF. MSG_PEEK doesn't
        # consume the buffer, so this doesn't disturb journal's own peek.
        try:
            if sys.platform == 'win32':
                raw = self.sock.sock
                raw.setblocking(False)
                try:
                    probe = raw.recv(1, socket.MSG_PEEK)
                finally:
                    raw.setblocking(True)
            else:
                probe = self.sock.sock.recv(1, socket.MSG_PEEK | socket.MSG_DONTWAIT)
        except BlockingIOError:
            pass
        except OSError as e:
            if self._handle_disconnect(e):
                return False
            raise
        else:
            if probe == b'':
                e = EOFError()
                if self._handle_disconnect(e):
                    return False
                raise e

        try:
            return super().try_wait()
        except (EOFError, OSError) as e:
            if self._handle_disconnect(e):
                return False
            raise

    def _login(self):
        token = self._token_provider() if self._token_provider else self._token
        login_req = {
            'action': 'request',
            'what': 'shel-login',
            'user-id': self._user_id,
        }
        if token:
            login_req['token'] = token
        handle = self.request(login_req)
        handle.wait()
        handle.raise_on_error()

    def reconnect(self):
        """
        Reconnect once: new socket, re-login (via token_provider if one was
        given, otherwise the same static token), then replay every
        subscription that hadn't been explicitly cancelled.

        Raises immediately on any failure (connection refused, login
        rejected, a resubscribe error) -- does not retry itself. Use
        wait_and_reconnect() if you want retries with backoff instead.

        On success: connection_state -> CONNECTED, disconnect_reason
        cleared, on_reconnect() fired if provided.

        Meant for a momentary blip where a single attempt is likely to
        succeed immediately. For a same-day outage worth waiting out (a
        crashed process being restarted by its supervisor, or the nightly
        maintenance window if token_provider transparently refreshes), see
        wait_and_reconnect().
        """
        self._rate_limiter.check_and_record()
        to_replay = list(self._active_subscriptions.values())  # snapshot; not
        # cleared yet, so a failed attempt below leaves it intact for retry

        self.connect(self.host, self.port)
        self.futures = {}
        self._login()

        self._active_subscriptions.clear()
        self._next_subscription_key = 0
        for method_name, kwargs in to_replay:
            getattr(self, method_name)(**kwargs)

        self.connection_state = ConnectionState.CONNECTED
        self.disconnect_reason = None
        if self._on_reconnect:
            self._on_reconnect()

    def wait_and_reconnect(self, timeout=None, initial_backoff=10.0, max_backoff=30.0):
        """
        Call reconnect() repeatedly with exponential backoff until it
        succeeds, until the rate limiter raises ConnectionRateLimitError
        (propagated immediately, not retried), or until `timeout` seconds
        have elapsed (raises the last failure; never gives up if timeout
        is None).

        Defaults are deliberately spaced (10s, 20s, 30s, 30s, ...) and never
        drop below the 30s cap no matter how long `timeout` runs -- at most
        2 attempts per 60 seconds, comfortably under the default rate
        limiter's 5-per-60s budget regardless of how large `timeout` is
        (including the default's 6-hour span, sized for the nightly
        maintenance window). The timeout itself is what ends a losing
        streak, not the rate limiter cutting it short first. If you widen
        the rate limiter or shrink the backoff, recheck that the two still
        stay in step over your chosen timeout.

        This is a convenience for "I know this is probably a bounded,
        recoverable outage, ride it out" -- not for blindly calling this on
        every disconnect regardless of cause. Doing so would reintroduce
        exactly the silent-masking risk described on the class docstring.
        Reserve it for situations you've identified as safe to auto-retry
        (a known crash-and-supervisor-restart cycle, or the nightly
        maintenance window if token_provider is wired to something that
        transparently refreshes).
        """
        start = time.monotonic()
        backoff = initial_backoff
        while True:
            try:
                self.reconnect()
                return
            except ConnectionRateLimitError:
                raise
            except (EOFError, OSError, journal.RequestError):
                if timeout is not None and (time.monotonic() - start) >= timeout:
                    raise
                time.sleep(backoff)
                backoff = min(backoff * 2, max_backoff)

    def subscribe_news(self, callback, sources=None, mode='headlines', format_id=1):
        """
        Subscribe to the live news stream.

        Parameters
        ----------
        callback : callable
            Called with each parsed event dict. msg_type values:
            ``subscribed``, ``news_item``, ``edgar_item``, ``court_case``.
        sources : list[str], optional
            3-character source codes e.g. ``['DJN', 'PRN']``.
            Omit to receive all entitled sources.
        mode : str
            ``'headlines'`` (default) or ``'full'``. ``'full'`` includes
            stripped plain-text body for sources that carry one.
            Body is never included for FTI regardless of mode.
        format_id : int
            Payload format version. Currently only ``1`` is defined.

        Returns
        -------
        SessionFuture
            Blocks on ``.wait()``. Call ``.cancel()`` to disconnect.
        """
        req = {
            'action':    'request',
            'what':      'news-gateway',
            'mode':      mode,
            'format-id': format_id,
        }
        if sources is not None:
            req['sources'] = [s.upper() for s in sources]

        future = self.request(req, _NdjsonHandler(callback, _news_post_process).handle)
        return self._track_subscription(
            'subscribe_news',
            dict(callback=callback, sources=sources, mode=mode, format_id=format_id),
            future,
        )

    def subscribe_scribe(self, callback, format_id=1):
        """
        Subscribe to the live Scribe stream (earnings call events and transcripts).

        Parameters
        ----------
        callback : callable
            Called with each parsed event dict. msg_type values:
            ``subscribed``, ``scribe_event``, ``scribe_transcript``.
            All events are delivered regardless of status (scheduled/live/concluded);
            filter client-side using the ``status`` field on ``scribe_event`` messages.
        format_id : int
            Payload format version. Currently only ``1`` is defined.

        Returns
        -------
        SessionFuture
            Blocks on ``.wait()``. Call ``.cancel()`` to disconnect.
        """
        req = {
            'action':    'request',
            'what':      'scribe-gateway',
            'format-id': format_id,
        }
        future = self.request(req, _NdjsonHandler(callback).handle)
        return self._track_subscription(
            'subscribe_scribe',
            dict(callback=callback, format_id=format_id),
            future,
        )

    def subscribe_social(self, callback, platforms=None, format_id=1):
        """
        Subscribe to the live social media stream.

        Parameters
        ----------
        callback : callable
            Called with each parsed event dict. msg_type values:
            ``subscribed``, ``social_post``.
            Each ``social_post`` includes a ``platform`` field
            (``'twitter'`` or ``'truth_social'``).
        platforms : list[str], optional
            Platforms to subscribe to: ``['twitter']``, ``['truth_social']``,
            or ``['twitter', 'truth_social']``.
            Omit to receive all entitled platforms.
        format_id : int
            Payload format version. Currently only ``1`` is defined.

        Returns
        -------
        SessionFuture
            Blocks on ``.wait()``. Call ``.cancel()`` to disconnect.
        """
        req = {
            'action':    'request',
            'what':      'social-gateway',
            'format-id': format_id,
        }
        if platforms is not None:
            req['platforms'] = [p.lower() for p in platforms]

        future = self.request(req, _NdjsonHandler(callback).handle)
        return self._track_subscription(
            'subscribe_social',
            dict(callback=callback, platforms=platforms, format_id=format_id),
            future,
        )

    def get_news_sources(self):
        """
        Query the server for the catalogue of available news sources.

        One-shot request — does not require any particular entitlement.
        Returns the full list of sources the server knows about, regardless
        of what the caller is entitled to receive.

        Returns
        -------
        list[dict]
            One dict per source with keys: ``category``,
            ``category_display_name``, ``source``, ``display_name``,
            ``short_display_name``, ``entitlement_key``,
            ``default_entitlement``.
        """
        result_holder = []
        pipe = _ByteFIFO()

        def on_data(data):
            pipe.write(data)
            line = pipe.readline()
            if line:
                result_holder.append(ujson.loads(line))

        handle = self.request({'action': 'request', 'what': 'news-sources'}, on_data)
        handle.wait()
        handle.raise_on_error()
        return result_holder[0] if result_holder else []


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description='Subscribe to the SHEL News Gateway and print events to stdout.'
    )

    env_group = parser.add_mutually_exclusive_group()
    env_group.add_argument(
        '--prod-env', action='store_const', dest='env', const='prod', default='prod',
        help='Connect to the production environment (default)',
    )
    env_group.add_argument(
        '--staging-env', action='store_const', dest='env', const='staging',
        help='Connect to the staging environment',
    )
    env_group.add_argument(
        '--custom-env', metavar='HOST:PORT', dest='env',
        help='Connect to a custom host:port',
    )

    parser.add_argument('-u', '--user', required=True, help='SHEL user ID')
    parser.add_argument('--token', default=None, metavar='JWT',
                        help='JWT token from https://shel.trilliumtrading.com for verified login')
    parser.add_argument(
        '--feed', choices=['news', 'scribe'], default='news',
        help='Feed to subscribe to (default: news). In prod, news and scribe are '
             'separate GatewayMode-restricted instances, so this also selects which '
             'one --prod-env connects to.',
    )
    parser.add_argument(
        '--sources', nargs='*', metavar='SRC',
        help='3-char source codes to subscribe to, e.g. FTI DJN PRN. '
             'Omit to receive all entitled sources. Ignored for --feed scribe.',
    )
    parser.add_argument(
        '--mode', choices=['headlines', 'full'], default='headlines',
        help='headlines (default): headline + teaser only. '
             'full: also includes stripped plain-text body.',
    )
    parser.add_argument(
        '--format-id', type=int, default=1, metavar='N',
        help='Payload format version (default: 1)',
    )
    parser.add_argument(
        '--json', action='store_true',
        help='Print each event as a single JSON line (default: Python repr)',
    )
    parser.add_argument(
        '--max-attempts', type=int, default=5, metavar='N',
        help='Max connection attempts per rate-limit window (default: 5)',
    )
    parser.add_argument(
        '--window', type=int, default=60, metavar='SECONDS',
        help='Rate-limit window in seconds (default: 60)',
    )

    args = parser.parse_args()

    from . import environments

    if args.env == 'prod':
        env = environments.ProdScribe if args.feed == 'scribe' else environments.ProdNews
    elif args.env == 'staging':
        env = environments.Staging
    else:
        try:
            host, port = args.env.rsplit(':', 1)
            env = environments.Environment(host, int(port))
        except ValueError:
            parser.error(f'--custom-env must be HOST:PORT, got: {args.env}')

    limiter = ConnectionRateLimiter(
        max_attempts=args.max_attempts,
        window_seconds=args.window,
    )

    handle = None
    cancelled = False

    def signal_handler(sig, frame):
        nonlocal cancelled
        cancelled = True
        if handle:
            sys.stderr.write('Cancelling subscription...\n')
            handle.cancel()

    signal.signal(signal.SIGINT, signal_handler)

    def on_event(obj):
        if args.json:
            print(ujson.dumps(obj), flush=True)
        else:
            print(obj, flush=True)

    def on_disconnect(exc):
        sys.stderr.write(f'Connection lost ({type(exc).__name__}); attempting to recover...\n')

    def on_reconnect():
        sys.stderr.write('Reconnected.\n')

    # A static --token is used as-is, matching the old behavior exactly. If
    # none was given, use auth.get_token as a token_provider rather than
    # calling it once upfront -- so a reconnect hours later (or after the
    # nightly restart) can transparently pick up a still-valid cached token,
    # or a refreshed one, instead of replaying whatever was captured at
    # startup.
    if args.token is not None:
        token_kwargs = {'token': args.token}
    else:
        token_kwargs = {'token_provider': lambda: auth.get_token(args.user)}

    try:
        with NewsGatewayClient(
            env, user_id=args.user, rate_limiter=limiter,
            on_disconnect=on_disconnect, on_reconnect=on_reconnect,
            **token_kwargs,
        ) as client:
            if args.feed == 'scribe':
                handle = client.subscribe_scribe(on_event, format_id=args.format_id)
            else:
                handle = client.subscribe_news(
                    on_event,
                    sources=args.sources,
                    mode=args.mode,
                    format_id=args.format_id,
                )
            # Loop on the session's own wait(), not handle.wait(): after any
            # auto-reconnect the resubscribed request gets a new request id,
            # so the original `handle` can no longer track completion by
            # itself. client.wait() keeps working across that regardless,
            # since it operates on whatever's currently outstanding rather
            # than one specific id -- see the outstanding_request_count()
            # check below for how "genuinely ended" is told apart from
            # "just recovered and still going."
            while not cancelled:
                try:
                    client.wait()
                except (EOFError, OSError) as e:
                    sys.stderr.write(f'Connection lost and could not be recovered: '
                                     f'{type(e).__name__}: {e}\n')
                    sys.exit(1)
                except auth.TokenPromptUnavailable as e:
                    sys.stderr.write(f'{e}\n')
                    sys.exit(1)

                if client.outstanding_request_count() == 0 and not cancelled:
                    # Nothing left outstanding and we weren't cancelled --
                    # our subscription itself ended (rejected, or the server
                    # closed it for some other reason), not a recovered
                    # disconnect (which would have already re-added a fresh
                    # outstanding request via the replayed subscribe).
                    try:
                        handle.raise_on_error()
                    except journal.RequestError as e:
                        sys.stderr.write(f'Subscription ended with error <{e.status_code}>: {e}\n')
                        sys.exit(1)
                    sys.stderr.write('Subscription ended unexpectedly.\n')
                    sys.exit(1)
    except ConnectionRateLimitError as e:
        sys.stderr.write(f'Rate limit: {e}\n')
        sys.exit(1)
