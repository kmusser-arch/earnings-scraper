class Environment:
    """
    Connection parameters for a SHELDataEngine instance.

    When the server is running in split GatewayMode (news/scribe/social),
    each feed type runs as a separate instance on a different port.
    Create one Environment per instance and one NewsGatewayClient per feed:

        news_client   = NewsGatewayClient(Environment(host, news_port),   ...)
        scribe_client = NewsGatewayClient(Environment(host, scribe_port), ...)
        social_client = NewsGatewayClient(Environment(host, social_port), ...)
    """
    def __init__(self, shel_data_engine_host, shel_data_engine_port):
        self.SHEL_DATA_ENGINE_HOST = shel_data_engine_host
        self.SHEL_DATA_ENGINE_PORT = shel_data_engine_port


# Staging: still unified (GatewayMode=all), news/scribe/social on one instance.
Staging = Environment('catdvdevbld01.idm.trlm.com', 65502)

# Production: split by GatewayMode as of TL-9137. Prod now points to the
# dedicated news-only instance; ProdNews is the same thing under a name that's
# symmetric with ProdScribe, prefer ProdNews in new code. Prod is kept exactly
# as-is since existing callers already depend on it meaning "news in prod".
# social-gateway is not available in production yet.
#
# Host is e1tdvprdapp01.idm.trlm.com -- confirmed by infra (IN-5204) as the
# canonical FQDN, and confirmed end-to-end (real subscribed data) from three
# separate networks: internal dev, an internal Windows machine, and QA's
# actual office machine via --custom-env. e1tdvprdapp01.trlm.com, used
# earlier, turned out to resolve to an unrelated address that doesn't
# forward the gateway port at all.
Prod       = Environment('e1tdvprdapp01.idm.trlm.com', 65502)  # GatewayMode=news
ProdNews   = Prod
ProdScribe = Environment('e1tdvprdapp01.idm.trlm.com', 65504)  # GatewayMode=scribe
