"""
Auto-fetch and cache a SHEL JWT so traders aren't prompted more than once a day.

Mirrors the pattern shel-datagateway's Session already uses: exchange a
username/password for a 24h JWT via POST /auth, then reuse it until it's
close to expiry. Only the token is cached, never the password.

The cache is scoped per user_id (one file per identity) so a shared machine,
or a script that talks to multiple SHEL accounts, never reuses one person's
token for another. The cached token's own username claim is also checked
against the requested user_id before it's trusted, since the server derives
the authoritative identity from that claim, not from anything the client
sends, a stale or misnamed cache file must never be allowed to silently log
someone in as the wrong person.
"""

import base64
import getpass
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request

TOKEN_CACHE_DIR = os.path.expanduser('~/.shel')
AUTH_URL = 'https://shel.trilliumtrading.com:8443/api/data-gateway/v1/auth'

# Refuse to use a cached token this close to expiry rather than race a
# request that might land after the server has already rejected it.
_EXPIRY_SAFETY_MARGIN_SECONDS = 300

# isatty() only tells you stdin is a terminal, not that a human is actually
# at it -- a terminal left open unattended (overnight, over a weekend) is
# still a tty. Bound the prompt so that case fails the same observable way
# an actually-headless process does, instead of blocking forever.
_PROMPT_TIMEOUT_SECONDS = 60


class TokenPromptUnavailable(Exception):
    """
    Raised instead of prompting when there's no cached token and no
    interactive terminal to ask for a password. Deliberately not caught
    anywhere in the reconnect machinery, so it surfaces immediately rather
    than blocking on a prompt that will never be answered (an unattended
    process left waiting overnight), or being silently absorbed into the
    same retry/cooldown cycle as an ordinary transient network failure --
    this specifically means a human needs to refresh the cached token from
    an interactive session before anything can proceed automatically.
    """
    pass


def _cache_path(user_id):
    safe = re.sub(r'[^A-Za-z0-9_.-]', '_', user_id)
    return os.path.join(TOKEN_CACHE_DIR, f'token.{safe}')


def _decode_payload(token):
    payload = token.split('.')[1]
    payload += '=' * (-len(payload) % 4)  # restore base64url padding
    return json.loads(base64.urlsafe_b64decode(payload))


def _cached_token(user_id):
    try:
        token = open(_cache_path(user_id)).read().strip()
        payload = _decode_payload(token)
        if payload.get('username') != user_id:
            return None  # cache file doesn't belong to this identity
        if payload.get('exp', 0) - _EXPIRY_SAFETY_MARGIN_SECONDS > time.time():
            return token
    except (FileNotFoundError, ValueError, IndexError, KeyError, TypeError):
        pass  # missing, expired, mismatched, or corrupted cache - refetch
    return None


def _cache_token(user_id, token):
    os.makedirs(TOKEN_CACHE_DIR, exist_ok=True)
    path = _cache_path(user_id)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write(token)


def _fetch_token(user_id, password, auth_url):
    credentials = base64.b64encode(f'{user_id}:{password}'.encode()).decode()
    req = urllib.request.Request(
        auth_url, method='POST', headers={'Authorization': f'Basic {credentials}'}
    )
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read())['token']
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise ValueError('SHEL authentication failed: incorrect username or password') from e
        raise


def _getpass_with_timeout(prompt, timeout):
    """
    Like getpass.getpass(), but gives up after `timeout` seconds instead of
    blocking forever, so an interactive-but-unattended terminal fails the
    same observable way a headless process does rather than hanging.

    Runs the (blocking) real getpass call in a daemon thread and joins with
    a timeout, rather than signal.alarm(), since alarm is POSIX-only and
    this package also supports Windows (see the win32 branch in
    NewsGatewayClient.try_wait()). If nobody responds in time, that thread
    is simply abandoned still waiting on the read -- harmless, since the
    caller is about to raise past this point regardless.
    """
    result = {}

    def _read():
        try:
            result['password'] = getpass.getpass(prompt)
        except Exception as e:
            result['error'] = e

    thread = threading.Thread(target=_read, daemon=True)
    thread.start()
    thread.join(timeout)

    if thread.is_alive():
        raise TokenPromptUnavailable(
            f"No password entered within {timeout}s of prompting. Treating "
            f"this the same as an unattended session -- refresh the token "
            f"from an interactive session first."
        )
    if 'error' in result:
        raise result['error']
    return result['password']


def get_token(user_id, auth_url=AUTH_URL, prompt_timeout=_PROMPT_TIMEOUT_SECONDS):
    """
    Return a cached JWT if one is still valid and belongs to user_id,
    otherwise prompt once for the SHEL password, fetch a fresh token, and
    cache it for next time.

    Raises TokenPromptUnavailable instead of prompting if stdin isn't an
    interactive terminal -- e.g. this is called from an unattended process
    (used as a reconnect() token_provider with nobody watching) -- rather
    than blocking forever on a password nobody is there to type. Also
    raises it if a real terminal is attached but nobody answers the prompt
    within prompt_timeout seconds -- isatty() alone can't tell a human at
    the keyboard apart from a terminal left open unattended.
    """
    token = _cached_token(user_id)
    if token:
        return token

    if not sys.stdin.isatty():
        raise TokenPromptUnavailable(
            f"No valid cached token for {user_id} and no interactive "
            f"terminal to prompt for a password (stdin is not a tty). "
            f"Refresh the token from an interactive session first."
        )

    password = _getpass_with_timeout(f'SHEL password for {user_id}: ', prompt_timeout)
    token = _fetch_token(user_id, password, auth_url)
    _cache_token(user_id, token)
    return token
