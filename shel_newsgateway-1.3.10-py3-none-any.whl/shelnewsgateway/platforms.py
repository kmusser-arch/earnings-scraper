from dataclasses import dataclass


@dataclass(frozen=True)
class PlatformDef:
    description: str
    entitlement: str


# Authoritative registry of social media platforms served by the social gateway.
PLATFORMS = {
    'twitter':      PlatformDef('Twitter',      'Social_Twitter'),
    'truth_social': PlatformDef('Truth Social', 'Social_TruthSocial'),
}
