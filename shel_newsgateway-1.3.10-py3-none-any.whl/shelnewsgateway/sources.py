from dataclasses import dataclass


@dataclass(frozen=True)
class SourceDef:
    description: str
    provider:    str
    feed_type:   str        # 'direct' | 'aggregator' | 'scraped'
    entitlement: str
    strip_body:  bool = False


# Authoritative registry of source codes served by the news gateway.
# Source of truth: https://trillium.atlassian.net/wiki/spaces/TF/pages/3064954898
# (SHEL News Codes & Content Browser Behavior)
#
# strip_body=True: body must never be forwarded to clients (contractual/policy).
# entitlement: must match the string checked by EntitlementsResource::has_entitlement().
#
# NOTE: PCR (not COR) is the correct PACER source code per the spec above.
#       NewsDataDefs.h uses COR — that is a bug on the C++ side.
SOURCES = {
    # Direct feeds
    'FTI':  SourceDef('Financial Times',      'FTI',      'direct',     'FT_FULL',            strip_body=True),
    'TIF':  SourceDef('The Information',      'TIF',      'direct',     'INF_COM'),
    # Indirect / aggregator feeds (Newsware)
    'DJN':  SourceDef('Dow Jones',            'Newsware', 'aggregator', 'NEWS_DowJones'),
    'FLY':  SourceDef('Fly on the Wall',      'Newsware', 'aggregator', 'NEWS_FlyOnTheWall'),
    'SIN':  SourceDef('Street Insider',       'Newsware', 'aggregator', 'NEWS_StreetInsider'),
    'HAM':  SourceDef('Hammerstone',          'Newsware', 'aggregator', 'NEWS_Hammerstone'),
    # Press releases (Newsware, NEWS_Presswires entitlement)
    'PRN':  SourceDef('PR Newswire',          'Newsware', 'aggregator', 'NEWS_Presswires'),
    'BUS':  SourceDef('BusinessWire',         'Newsware', 'aggregator', 'NEWS_Presswires'),
    'NFI':  SourceDef('Newsfile',             'Newsware', 'aggregator', 'NEWS_Presswires'),
    'ASW':  SourceDef('AccessWire',           'Newsware', 'aggregator', 'NEWS_Presswires'),
    'PZM':  SourceDef('Globe Newswire',       'Newsware', 'aggregator', 'NEWS_Presswires'),
    # Scraped news (Synoptic, SCRAPED_NEWS entitlement)
    'SEM':  SourceDef('Semafor',              'Synoptic', 'scraped',    'Semafor'),
    'NYT':  SourceDef('New York Times',       'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'BBG':  SourceDef('Bloomberg',            'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'RTN':  SourceDef('Reuters',              'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'CNB':  SourceDef('CNBC',                 'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'FRB':  SourceDef('Forbes',               'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'FRT':  SourceDef('Fortune',              'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'MKT':  SourceDef('MarketWatch',          'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'BRR':  SourceDef("Barron's",             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'NBC':  SourceDef('NBC News',             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'ABC':  SourceDef('ABC News',             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'CBS':  SourceDef('CBS News',             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'CNN':  SourceDef('CNN',                  'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'PBS':  SourceDef('PBS NewsHour',         'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'WPT':  SourceDef('Washington Post',      'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'WSJ':  SourceDef('Wall Street Journal',  'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'USA':  SourceDef('USA Today',            'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'LAT':  SourceDef('Los Angeles Times',    'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'ATL':  SourceDef('The Atlantic',         'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'HUF':  SourceDef('HuffPost',             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'NWK':  SourceDef('Newsweek',             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'MSN':  SourceDef('MSNBC',               'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'FOX':  SourceDef('Fox News',             'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    'UNDF': SourceDef('Undefined Scraped',    'Synoptic', 'scraped',    'SCRAPED_NEWS'),
    # Regulatory / reference feeds
    'EDG':  SourceDef('SEC EDGAR filings',    'Newsware', 'aggregator', 'Edgar'),
    'PCR':  SourceDef('Court/PACER',          'Synoptic', 'scraped',    'PACER'),
    # Non-article event feeds (not in GUI content browser spec)
    'ADD':  SourceDef('S&P 500 additions',    'Synoptic', 'scraped',    'SP500'),
}

# Sources where body must never be forwarded to clients.
NO_BODY_SOURCES: frozenset = frozenset(
    code for code, s in SOURCES.items() if s.strip_body
)
